const formatNumber = (num) => {
    num = Number(num);
  
    if (!num) return "0";
    if (num >= 1e12) return (num / 1e12).toFixed(2) + "T";
    if (num >= 1e9) return (num / 1e9).toFixed(2) + "B";
    if (num >= 1e6) return (num / 1e6).toFixed(2) + "M";
    if (num >= 1e3) return (num / 1e3).toFixed(2) + "K";
  
    return num.toString();
  };
  
  module.exports = {
    formatNumber,
  };