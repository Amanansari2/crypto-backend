const axios = require("axios");
const config = require("../../config/binannce");

const getOrderBook = async (symbol) => {

  const { data } = await axios.get(
    `${config.baseUrl}/depth`,
    {
      params: {
        symbol,
        limit: 2000,
      },
    }
  );

  return data;
};

module.exports = {
  getOrderBook,
};