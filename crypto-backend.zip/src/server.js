const app = require("./app");
const env = require("./config/env");
const sequelize = require("./config/db");
const logger = require("./utils/logger");
const syncBinancePairs = require("./services/binance/binance.sync.service");
const startBinanceJob = require("./jobs/binance/binance.job");

const startServer = async () => {
  app.listen(env.port, async () => {
    logger.info(`Server running on port ${env.port}`);

    try {
      await sequelize.authenticate();
      logger.info("Database connected");

      await syncBinancePairs();
      startBinanceJob();
    } catch (error) {
      const message =
        error && (error.message || error.original?.message || error.name)
          ? error.message || error.original?.message || error.name
          : "Unknown database connection error";

      logger.error("Database connection failed:", message);
      logger.warn("API is running, but database-dependent routes may fail.");
    }
  });
};

startServer();
